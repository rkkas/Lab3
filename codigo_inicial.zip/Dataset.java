import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Dataset {
    private ArrayList<Game> data;             
    private String sortedByAttribute;         

 
    public Dataset(ArrayList<Game> data) {
        this.data = data;
        this.sortedByAttribute = "";
    }


    public ArrayList<Game> getGamesByPrice(int price) {
        ArrayList<Game> resultado = new ArrayList<>();
        
        if (sortedByAttribute.equals("price")) {

            int izquierda = 0;
            int derecha = data.size() - 1;

            while (izquierda <= derecha) {
                int medio = (izquierda + derecha) / 2;
                int precioMedio = data.get(medio).getPrice();

                if (precioMedio == price) {
                    int i = medio;

        
                    while (i >= 0 && data.get(i).getPrice() == price) {
                        i--;
                    }
                      i++; 

           
                    while (i < data.size() && data.get(i).getPrice() == price) {
                        resultado.add(data.get(i));
                        i++;
                    }
                    break;
                } else if (precioMedio < price) {
                    izquierda = medio + 1;
                } else {
                    derecha = medio - 1;
                }
            }
        } else {
        
            for (int i = 0; i < data.size(); i++) {
                Game juego = data.get(i);
                if (juego.getPrice() == price) {
                    resultado.add(juego);
                }
            }
        }

        return resultado;
    }

    public ArrayList<Game> getGamesByPriceRange(int lowerPrice, int higherPrice) {
        ArrayList<Game> resultado = new ArrayList<>();

        for (int i = 0; i < data.size(); i++) {
            Game juego = data.get(i);
            int precio = juego.getPrice();
            if (precio >= lowerPrice && precio <= higherPrice) {
                resultado.add(juego);
            }
        }

        return resultado;
    }
 
    public ArrayList<Game> getGamesByCategory(String category) {
        ArrayList<Game> resultado = new ArrayList<>();

        for (int i = 0; i < data.size(); i++) {
            Game juego = data.get(i);
            if (juego.getCategory().equalsIgnoreCase(category)) {
                resultado.add(juego);
            }
        }

        return resultado;
    }
  
    public ArrayList<Game> getGamesByQuality(int quality) {
        ArrayList<Game> resultado = new ArrayList<>();

        for (int i = 0; i < data.size(); i++) {
            Game juego = data.get(i);
            if (juego.getQuality() == quality) {
                resultado.add(juego);
            }
        }

        return resultado;
    }

    public ArrayList<Game> sortByAlgorithm(String algorithm, String attribute) {
        Comparator<Game> comparador;


        if (attribute.equals("price")) {
            comparador = new Comparator<Game>() {

                public int compare(Game g1, Game g2) {
                    return Integer.compare(g1.getPrice(), g2.getPrice());
                }
            };
        } else if (attribute.equals("quality")) {
            comparador = new Comparator<Game>() {
          
                public int compare(Game g1, Game g2) {
                    return Integer.compare(g1.getQuality(), g2.getQuality());
                }
            };
        } else if (attribute.equals("category")) {
            comparador = new Comparator<Game>() {
        
                public int compare(Game g1, Game g2) {
                    return g1.getCategory().compareTo(g2.getCategory());
                }
            };
        } else {
         
            comparador = new Comparator<Game>() {
     
                public int compare(Game g1, Game g2) {
                    return Integer.compare(g1.getPrice(), g2.getPrice());
                }
            };
        }

        if (algorithm.equals("bubbleSort")) {
            bubbleSort(comparador);
        } else if (algorithm.equals("insertionSort")) {
            insertionSort(comparador);
        } else if (algorithm.equals("selectionSort")) {
            selectionSort(comparador);
        } else {
   
            Collections.sort(data, comparador);
        }

      
        sortedByAttribute = attribute;

        return data;
    }

    private void bubbleSort(Comparator<Game> comparador) {
        int n = data.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (comparador.compare(data.get(j), data.get(j + 1)) > 0) {
                    Collections.swap(data, j, j + 1);
                }
            }
        }
    }

    private void insertionSort(Comparator<Game> comparador) {
        for (int i = 1; i < data.size(); i++) {
            Game actual = data.get(i);
            int j = i - 1;

            while (j >= 0 && comparador.compare(data.get(j), actual) > 0) {
                data.set(j + 1, data.get(j));
                j--;
            }

            data.set(j + 1, actual);
        }
    }

    private void selectionSort(Comparator<Game> comparador) {
        int n = data.size();
        for (int i = 0; i < n - 1; i++) {
            int minimo = i;

            for (int j = i + 1; j < n; j++) {
                if (comparador.compare(data.get(j), data.get(minimo)) < 0) {
                    minimo = j;
                }
            }

            Collections.swap(data, i, minimo);
        }
    }
}
