import java.util.ArrayList;
import java.util.Random;

public class GenerateData {
    public static ArrayList<Game> generarLista(int N) {
        ArrayList<Game> lista = new ArrayList<>();
        Random random = new Random();

        String[] palabras = {"Dragon", "Empire", "Quest", "Galaxy", "Legends", "Warrior"};
        String[] categorias = {"Acción", "Aventura", "Estrategia", "RPG", "Deportes", "Simulación"};

        for (int i = 0; i < N; i++) {
            String nombre = palabras[random.nextInt(palabras.length)] + palabras[random.nextInt(palabras.length)];
            String categoria = categorias[random.nextInt(categorias.length)];
            int precio = random.nextInt(70001);
            int calidad = random.nextInt(101);

            Game juego = new Game(nombre, categoria, precio, calidad);
            lista.add(juego);
        }

        return lista;
    }

    public static void main(String[] args) {
        ArrayList<Game> juegos = generarLista(10);
        for (Game g : juegos) {
            System.out.println(g);
        }
    }
}
