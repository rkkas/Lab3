import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Game> listaDeJuegos = GenerateData.generarLista(10);

        Dataset conjuntoDeJuegos = new Dataset(listaDeJuegos);
        conjuntoDeJuegos.sortByAlgorithm("bubbleSort", "price");

        System.out.println("Juegos ordenados por precio:");
        for (Game juego : listaDeJuegos) {
            System.out.println(juego);
        }

        System.out.println("\nJuegos con precio exacto $25000:");
        ArrayList<Game> juegosConPrecio25000 = conjuntoDeJuegos.getGamesByPrice(25000);
        for (Game juego : juegosConPrecio25000) {
            System.out.println(juego);
        }

        System.out.println("\nJuegos de categoría 'Aventura':");
        ArrayList<Game> juegosDeCategoriaAventura = conjuntoDeJuegos.getGamesByCategory("Aventura");
        for (Game juego : juegosDeCategoriaAventura) {
            System.out.println(juego);
        }
    }
}
