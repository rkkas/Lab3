import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Dataset {
    private ArrayList<Game> data;
    private String sortedByAttribute;

    public Dataset(ArrayList<Game> data) {
        this.data = data;
        this.sortedByAttribute = "";
    }

    public ArrayList<Game> getGamesByPrice(int price) {
        ArrayList<Game> resultado = new ArrayList<>();
        for (Game juego : data) {
            if (juego.getPrice() == price) {
                resultado.add(juego);
            }
        }
        return resultado;
    }

    public ArrayList<Game> getGamesByCategory(String category) {
        ArrayList<Game> resultado = new ArrayList<>();
        for (Game juego : data) {
            if (juego.getCategory().equalsIgnoreCase(category)) {
                resultado.add(juego);
            }
        }
        return resultado;
    }

    public ArrayList<Game> getGamesByQuality(int quality) {
        ArrayList<Game> resultado = new ArrayList<>();
        for (Game juego : data) {
            if (juego.getQuality() == quality) {
                resultado.add(juego);
            }
        }
        return resultado;
    }

    public ArrayList<Game> sortByAlgorithm(String algorithm, String attribute) {
        Comparator<Game> comparador;

        if (attribute.equals("price")) {
            comparador = Comparator.comparingInt(Game::getPrice);
        } else if (attribute.equals("quality")) {
            comparador = Comparator.comparingInt(Game::getQuality);
        } else if (attribute.equals("category")) {
            comparador = Comparator.comparing(Game::getCategory);
        } else {
            comparador = Comparator.comparingInt(Game::getPrice);
        }

        switch (algorithm) {
            case "bubbleSort": bubbleSort(comparador); break;
            case "insertionSort": insertionSort(comparador); break;
            case "selectionSort": selectionSort(comparador); break;
            default: Collections.sort(data, comparador);
        }

        sortedByAttribute = attribute;
        return data;
    }

    private void bubbleSort(Comparator<Game> comparador) {
        int n = data.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (comparador.compare(data.get(j), data.get(j + 1)) > 0) {
                    Collections.swap(data, j, j + 1);
                }
            }
        }
    }

    private void insertionSort(Comparator<Game> comparador) {
        for (int i = 1; i < data.size(); i++) {
            Game actual = data.get(i);
            int j = i - 1;
            while (j >= 0 && comparador.compare(data.get(j), actual) > 0) {
                data.set(j + 1, data.get(j));
                j--;
            }
            data.set(j + 1, actual);
        }
    }

    private void selectionSort(Comparator<Game> comparador) {
        int n = data.size();
        for (int i = 0; i < n - 1; i++) {
            int minimo = i;
            for (int j = i + 1; j < n; j++) {
                if (comparador.compare(data.get(j), data.get(minimo)) < 0) {
                    minimo = j;
                }
            }
            Collections.swap(data, i, minimo);
        }
    }
}
